package dev.danvega.hello_cli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloCliApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloCliApplication.class, args);
	}

}
