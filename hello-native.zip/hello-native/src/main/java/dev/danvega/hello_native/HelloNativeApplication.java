package dev.danvega.hello_native;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloNativeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloNativeApplication.class, args);
	}

}
