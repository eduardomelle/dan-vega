package dev.danvega.hello_native;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloNativeApplicationTests {

	@Test
	void contextLoads() {
	}

}
